<h1>Inclure des fichiers suivant l'arborescence</h1>
<i>
    Chemin du fichier qui est lancé : <?php echo __FILE__ ?>
</i>

<?php

    include "../fichier_1.php" ;
    include "../fichier_2.php" ;

    include "../dossier_1/fichier_1_1.php";



