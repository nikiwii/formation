<?php

$titre = "Menu du dimanche";

$entree = "brick au thon";
$plat = "courgettes farcies";
$dessert = "tarte au citron meringuée";

include "page_menu_du_jour.php";

$annee = 2020;
