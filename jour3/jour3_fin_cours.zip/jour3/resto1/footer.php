<footer>
  &copy; <?php echo $nom_du_resto ?>
  <div class="nav-bas">
    <?php include "navigation.php" ?>
  </div>
</footer>
