<?php

$titre = "Menu du Jeudi";

$entree = "salade betterave feta";
$plat = "gratin de courgettes";
$dessert = "yaourt maison";

include "page_menu_du_jour.php";
