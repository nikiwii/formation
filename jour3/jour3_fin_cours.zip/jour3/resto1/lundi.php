<?php

$titre = "Menu du lundi";

$entree = "Velouté de courgette";
$plat = "Saumon teriyaki aux légumes";
$dessert = "Gatêau au chocolat";

include "page_menu_du_jour.php";
