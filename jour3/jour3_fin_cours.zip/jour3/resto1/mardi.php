<?php

$titre = "Menu du Mardi";

$entree = "Oeufs à la diable mousse surimi";
$plat = "Gratin dauphinois";
$dessert = "crème brulée";

include "page_menu_du_jour.php";
