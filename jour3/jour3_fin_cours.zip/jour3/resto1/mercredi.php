<?php

$titre = "Menu du Mercredi";

$entree = "quiche aux poireaux";
$plat = "curry de poisson";
$dessert = "roulé mousse au chocolat";

include "page_menu_du_jour.php";
