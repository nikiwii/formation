<nav>
    <ul>
      <li>
            <a href="index.php">Accueil</a>
      </li>
      <li>
            <a href="lundi.php">Lundi</a>
      </li>
      <li>
            <a href="mardi.php">Mardi</a>
      </li>
        <li>
            <a href="mercredi.php">Mercredi</a>
        </li>
        <li>
            <a href="jeudi.php">Jeudi</a>
        </li>
        <li>
            <a href="vendredi.php">Vendredi</a>
        </li>
        <li>
            <a href="samedi.php">Samedi</a>
        </li>
        <li>
            <a href="dimanche.php">Dimanche</a>
        </li>
        <li>
            <a href="#">Où nous trouver</a>
        </li>

        <li>
            <a href="#">Bon plan</a>
        </li>
    </ul>
</nav>
