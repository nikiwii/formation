<?php

$titre = "Menu du Samedi";

$entree = "gratin de panais";
$plat = "poulet roti";
$dessert = "panna cotta à la crème de marrons";

include "page_menu_du_jour.php";

$annee = 2020;

?>
