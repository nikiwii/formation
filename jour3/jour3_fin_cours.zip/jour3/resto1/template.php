<!DOCTYPE html>
<html>

<head>
  <title><?php echo $titre?></title>
  <link rel="stylesheet" href="css/mes_styles.css" />
</head>

<body>

  <header>
    <div class="container">

      <nav>
          <ul>
            <li>
              <a href="page.php">PAGE 1</a>
            </li>
            <li>
              <a href="page.php?num=2">PAGE 2</a>
            </li>
            <li>
              <a href="page.php?num=3">PAGE 3</a>
            </li>
          </ul>
      </nav>

    </div>
  </header>

  <main>
    <div class="container">
      <h1><?php echo $titre?></h1>
      <div>
        <p>
          <?php echo $contenu;?>
        <p>
      </div>
    </div>
  </main>



</body>
</html>
