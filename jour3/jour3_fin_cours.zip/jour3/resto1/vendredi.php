<?php

$titre = "Menu du Vendredi";

$entree = "beignets de crevettes";
$plat = "gigot d’agneau";
$dessert = "cheesecake";

include "page_menu_du_jour.php";

$annee = 2020;

?>
