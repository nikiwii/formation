<?php
$nom_du_resto = "boheme";

$_dossier_template = "templates/site2020/"; // repertoire dans lequel j'ai mis l'ensemble des gabarits de mon site

$_url_base = "http://localhost/jour3/resto2/";
//  c'est l'url pour accéder à la page d'accueil de mon site.
//  si la racine de mon site était https://www.mon_super_resto.com/,
//  $_url_base = "https://www.mon_super_resto.com/";


//  $_url_base $_dossier_template css/mes_styles.css
