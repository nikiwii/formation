<?php

include "config.php";

$titre = "Menu du Dimanche";

$entree = "brick au thon";
$plat = "courgettes farcies";
$dessert = "tarte au citron meringuée";

include $_dossier_template  . "page_menu_du_jour.php";