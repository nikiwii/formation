<?php
include "config.php";
include $_dossier_template  . "accueil.php";
