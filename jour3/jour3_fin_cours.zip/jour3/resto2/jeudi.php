<?php

include "config.php";

$titre = "Menu du jeudi";

$entree = "salade betterave feta";
$plat = "gratin de courgettes";
$dessert = "yaourt maison";

include $_dossier_template  . "page_menu_du_jour.php";
