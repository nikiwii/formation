<?php
include "config.php";

$titre = "Menu du lundi";
$entree = "Velouté de courgette";
$plat = "Saumon teriyaki aux légumes";
$dessert = "Gatêau au chocolat";

echo $_dossier_template  . "page_menu_du_jour.php";


include $_dossier_template  . "page_menu_du_jour.php";
