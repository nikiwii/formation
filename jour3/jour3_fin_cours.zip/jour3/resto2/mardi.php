<?php

include "config.php";

$titre = "Menu du Mardi";

$entree = "Oeufs à la diable mousse surimi";
$plat = "Gratin dauphinois";
$dessert = "crème brulée";

include $_dossier_template  . "page_menu_du_jour.php";
