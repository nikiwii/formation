<?php

include "config.php";

$titre = "Menu du Mercredi";

$entree = "quiche aux poireaux";
$plat = "curry de poisson";
$dessert = "roulé mousse au chocolat";

include $_dossier_template  . "page_menu_du_jour.php";