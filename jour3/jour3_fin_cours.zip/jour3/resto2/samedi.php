<?php

include "config.php";

$titre = "Menu du Samedi";

$entree = "gratin de panais";
$plat = "poulet roti";
$dessert = "panna cotta à la crème de marrons";

include $_dossier_template  . "page_menu_du_jour.php";