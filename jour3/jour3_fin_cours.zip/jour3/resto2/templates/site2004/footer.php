<footer>
  &copy; <?php echo $nom_du_resto ?>
</footer>
